<style>
  @media (min-width: 768px){
.col-md-6 {
  max-width: 42%
}
@media (min-width: 768px){
  .new-mg{
    margin-left: -170px
  }
}
</style>
<div class="block-31" style="position: relative;">
  <div id="sync" class="owl-carousel owl-theme loop-block-31 block-30 item" data-stellar-background-ratio="0.5">
    <div class="block-30 overlay-header item" style="background-image: url('img/Random/20190929103851__MG_3451.JPG');">
      <section class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-7 text-center" style="padding-top:180px">
            <h2 class="heading">We are Bringing Divinity to Humanity</h2> 
          </div>
          <div class="col-md-6 col-sm-6 text-center">
            <a href="#" class="btn btn-primary btn-hover-white py-3 px-5 live-btn">Join Our Live Service</a>
          </div>
          <div class="col-md-4 col-sm-6 text-center new-mg">
            <a href="contact" class="btn btn-primary btn-hover-white py-3 px-5 new-btn">I'm New</a>
          </div>
        </div>
      </section>
    </div>
    <div class="block-30 overlay-header item" style="background-image: url('img/Random/20190519103013__MG_8533.jpg');">
      <section class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-7 text-center" style="padding-top:180px">
            <h2 class="heading">We are Bringing Divinity to Humanity</h2> 
          </div>
          <div class="col-md-6 col-sm-6 text-center">
            <a href="#" class="btn btn-primary btn-hover-white py-3 px-5 live-btn">Join Our Live Service</a>
          </div>
          <div class="col-md-4 col-sm-6 text-center new-mg">
            <a href="contact" class="btn btn-primary btn-hover-white py-3 px-5 new-btn">I'm New</a>
          </div>
        </div>
      </section>
    </div>
    <div class="block-30 overlay-header item" style="background-image: url('img/Pst-Desmond/20190609111411__MG_9523.jpg');">
      <section class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-7 text-center" style="padding-top:180px">
            <h2 class="heading">We are Bringing Divinity to Humanity</h2> 
          </div>
          <div class="col-md-6 col-sm-6 text-center">
            <a href="#" class="btn btn-primary btn-hover-white py-3 px-5 live-btn">Join Our Live Service</a>
          </div>
          <div class="col-md-4 col-sm-6 text-center new-mg">
            <a href="contact" class="btn btn-primary btn-hover-white py-3 px-5 new-btn">I'm New</a>
          </div>
        </div>
      </section>
    </div>
  </div>
</div>