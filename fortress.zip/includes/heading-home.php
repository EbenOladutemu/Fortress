<div class="block-31" style="position: relative;">
  <div id="sync" class="owl-carousel owl-theme loop-block-31 block-30 item" data-stellar-background-ratio="0.5">
    <div class="block-30 no-overlay item" style="background-image: url('img/Pst-Desmond/20190609111411__MG_9523.jpg');">
      <div id="heading-component">
        <heading-tag></heading-tag>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190505112549__MG_8305.jpg');">
      <div id="heading-component-2">
        <heading-tag></heading-tag>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190519103013__MG_8533.jpg');">
      <div id="heading-component-3">
        <heading-tag></heading-tag>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190519113649__MG_8577.jpg');">
      <div id="heading-component-4">
        <heading-tag></heading-tag>
      </div>
    </div>
  </div>
</div>