<div class="block-31" style="position: relative;">
  <div id="sync" class="owl-carousel owl-theme loop-block-31 block-30 item" data-stellar-background-ratio="0.5">
    <!-- <div class="block-30 no-overlay item" style="background-image: url('img/Pst-Desmond/20190609111411__MG_9523.jpg');">
      <div id="heading-component-25">
        <heading-tag-2></heading-tag-2>
      </div>
    </div> -->
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190609113610__MG_9570.jpg');">
      <div id="heading-component-26">
        <heading-tag-7></heading-tag-7>
      </div>
    </div>
    <!-- <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190519103013__MG_8533.jpg');">
      <div id="heading-component-27">
        <heading-tag-7></heading-tag-7>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190609114434__MG_9583.jpg');">
      <div id="heading-component-28">
        <heading-tag-7></heading-tag-7>
      </div>
    </div> -->
  </div>
</div>