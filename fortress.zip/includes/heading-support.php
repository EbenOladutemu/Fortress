<div class="block-31" style="position: relative;">
  <div id="sync" class="owl-carousel owl-theme loop-block-31 block-30 item" data-stellar-background-ratio="0.5">
    <div class="block-30 no-overlay item" style="background-image: url('img/Pst-Kelvin/20190605201554__MG_9388.jpg');">
      <div id="heading-component-21">
        <heading-tag-6></heading-tag-6>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190609114434__MG_9583.jpg');">
      <div id="heading-component-22">
        <heading-tag-6></heading-tag-6>
      </div>
    </div>
    <!--<div class="block-30 no-overlay item" style="background-image: url('img/Pst-Desmond/20190609111411__MG_9523.jpg');">
      <div id="heading-component-23">
        <heading-tag-6></heading-tag-6>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190609113610__MG_9570.jpg');">
      <div id="heading-component-24">
        <heading-tag-6></heading-tag-6>
      </div>
    </div> -->
  </div>
</div>