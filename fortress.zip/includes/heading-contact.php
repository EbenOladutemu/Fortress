<div class="block-31" style="position: relative;">
  <div id="sync" class="owl-carousel owl-theme loop-block-31 block-30 item" data-stellar-background-ratio="0.5">
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190609121838__MG_9606.jpg');">
      <div id="heading-component-17">
        <heading-tag-5></heading-tag-5>
      </div>
    </div><!-- 
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190609113610__MG_9570.jpg');">
      <div id="heading-component-18">
        <heading-tag-5></heading-tag-5>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190519103013__MG_8533.jpg');">
      <div id="heading-component-19">
        <heading-tag-5></heading-tag-5>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190609114434__MG_9583.jpg');">
      <div id="heading-component-20">
        <heading-tag-5></heading-tag-5>
      </div>
    </div> -->
  </div>
</div>