<div class="block-31" style="position: relative;">
  <div id="sync" class="owl-carousel owl-theme loop-block-31 block-30 item" data-stellar-background-ratio="0.5">
    <div class="block-30 no-overlay item" style="background-image: url('img/Pst-Kelvin/20190602105457__MG_9144.jpg');">
      <div id="heading-component-13">
        <heading-tag-4></heading-tag-4>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190609113336__MG_9563.jpg');">
      <div id="heading-component-14">
        <heading-tag-4></heading-tag-4>
      </div>
    </div><!-- 
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190519103013__MG_8533.jpg');">
      <div id="heading-component-15">
        <heading-tag-4></heading-tag-4>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190609114434__MG_9583.jpg');">
      <div id="heading-component-16">
        <heading-tag-4></heading-tag-4>
      </div>
    </div> -->
  </div>
</div>