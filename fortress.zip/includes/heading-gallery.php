<div class="block-31" style="position: relative;">
  <div id="sync" class="owl-carousel owl-theme loop-block-31 block-30 item" data-stellar-background-ratio="0.5">
    <div class="block-30 no-overlay item" style="background-image: url('img/Pst-Desmond/20190526111822__MG_8946.jpg');">
      <div id="heading-component-29">
        <heading-tag-8></heading-tag-8>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190505112549__MG_8305.jpg');">
      <div id="heading-component-30">
        <heading-tag-8></heading-tag-8>
      </div>
    </div>
    <!-- <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190519103013__MG_8533.jpg');">
      <div id="heading-component-31">
        <heading-tag-8></heading-tag-8>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Random/20190609114434__MG_9583.jpg');">
      <div id="heading-component-32">
        <heading-tag-8></heading-tag-8>
      </div>
    </div> -->
  </div>
</div>