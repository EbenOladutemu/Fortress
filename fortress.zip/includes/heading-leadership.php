<div class="block-31" style="position: relative;">
  <div id="sync" class="owl-carousel owl-theme loop-block-31 block-30 item" data-stellar-background-ratio="0.5">
    <div class="block-30 no-overlay item" style="background-image: url('img/Pst-Desmond/20190526111622__MG_8938.jpg');">
      <div id="heading-component-9">
        <heading-tag-3></heading-tag-3>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Pst-Jumoke/IMG-20190523-WA0003.jpg');">
      <div id="heading-component-10">
        <heading-tag-3></heading-tag-3>
      </div>
    </div>
    <div class="block-30 no-overlay item" style="background-image: url('img/Pst-Kelvin/20190602114606__MG_9191.jpg');">
      <div id="heading-component-11">
        <heading-tag-3></heading-tag-3>
      </div>
    </div>
    </div>
  </div>
</div>