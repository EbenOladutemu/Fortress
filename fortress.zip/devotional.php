<title>The Fortress International Church - Elixir of Life</title>
<?php include 'includes/head.php';?>
<?php include 'includes/nav-devotional.php';?>
<div class="block-31" style="position: relative;">
  <div id="sync" class="owl-carousel loop-block-31 block-30 item" data-stellar-background-ratio="0.5">
    <div class="block-30 overlay-header item" style="background-image: url('img/Random/20190609113610__MG_9570.jpg');">
      <section class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-7 text-center">
            <h2 class="heading">Our Devotional</h2>
          </div>
        </div>
      </section>
    </div>
  </div>
</div>
  
<h1 class="text-center">ELIXIR OF LIFE HERE</h1>
<!-- <div class="site-section">
  <div class="container">
    <div class="row">
      <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
        <div class="post-entry mb-5">
          <a href="blog-single" class="mb-3 img-wrap">
            <img src="images/img_4.jpg" alt="Image placeholder" class="img-fluid">
            <span class="date">July 26, 2018</span>
          </a>
          <h3><a href="blog-single">Be A Volunteer Today</a></h3>
          <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
          <p><a href="blog-single">Read More</a></p>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
        <div class="post-entry mb-5">
          <a href="blog-single" class="mb-3 img-wrap">
            <img src="images/img_5.jpg" alt="Image placeholder" class="img-fluid">
            <span class="date">July 26, 2018</span>
          </a>
          <h3><a href="blog-single">You May Save The Life of A Child</a></h3>
          <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
          <p><a href="blog-single">Read More</a></p>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
        <div class="post-entry mb-5">
          <a href="blog-single" class="mb-3 img-wrap">
            <img src="images/img_6.jpg" alt="Image placeholder" class="img-fluid">
            <span class="date">July 26, 2018</span>
          </a>
          <h3><a href="blog-single">Children That Needs Care</a></h3>
          <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
          <p><a href="blog-single">Read More</a></p>
        </div>
      </div>

      <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
        <div class="post-entry mb-5">
          <a href="blog-single" class="mb-3 img-wrap">
            <img src="images/img_4.jpg" alt="Image placeholder" class="img-fluid">
            <span class="date">July 26, 2018</span>
          </a>
          <h3><a href="blog-single">Be A Volunteer Today</a></h3>
          <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
          <p><a href="blog-single">Read More</a></p>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
        <div class="post-entry mb-5">
          <a href="blog-single" class="mb-3 img-wrap">
            <img src="images/img_5.jpg" alt="Image placeholder" class="img-fluid">
            <span class="date">July 26, 2018</span>
          </a>
          <h3><a href="blog-single">You May Save The Life of A Child</a></h3>
          <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
          <p><a href="blog-single">Read More</a></p>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
        <div class="post-entry mb-5">
          <a href="blog-single" class="mb-3 img-wrap">
            <img src="images/img_6.jpg" alt="Image placeholder" class="img-fluid">
            <span class="date">July 26, 2018</span>
          </a>
          <h3><a href="blog-single">Children That Needs Care</a></h3>
          <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
          <p><a href="blog-single">Read More</a></p>
        </div>
      </div>

      <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
        <div class="post-entry mb-5">
          <a href="blog-single" class="mb-3 img-wrap">
            <img src="images/img_4.jpg" alt="Image placeholder" class="img-fluid">
            <span class="date">July 26, 2018</span>
          </a>
          <h3><a href="blog-single">Be A Volunteer Today</a></h3>
          <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
          <p><a href="blog-single">Read More</a></p>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
        <div class="post-entry mb-5">
          <a href="blog-single" class="mb-3 img-wrap">
            <img src="images/img_5.jpg" alt="Image placeholder" class="img-fluid">
            <span class="date">July 26, 2018</span>
          </a>
          <h3><a href="blog-single">You May Save The Life of A Child</a></h3>
          <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
          <p><a href="blog-single">Read More</a></p>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
        <div class="post-entry mb-5">
          <a href="blog-single" class="mb-3 img-wrap">
            <img src="images/img_6.jpg" alt="Image placeholder" class="img-fluid">
            <span class="date">July 26, 2018</span>
          </a>
          <h3><a href="blog-single">Children That Needs Care</a></h3>
          <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
          <p><a href="blog-single">Read More</a></p>
        </div>
      </div>
    </div>
  </div>
</div> --> <!-- .site-section -->

<?php include 'includes/footer.php';?>  