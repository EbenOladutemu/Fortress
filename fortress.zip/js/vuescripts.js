var fortress = new Vue({
  el: '#uList',
  data:{
    textBold: ''
  }
});