<title>The Fortress International Church - Support</title>
<?php include 'includes/head.php';?>
<?php include 'includes/nav-support.php';?>
<?php include 'includes/heading-support.php';?>

  <div class="site-section">
    <div class="container">
      <div class="row block-9">
        <div class="col-md-12 pr-md-12">
          <h1 class="text-center">SUPPORT US</h1>
          <h4>Our Bank Details!</h4> 
            <p>THE FORTRESS INTERNATIONAL CHURCH.<br>
               ZENITH BANK.<br>
               1015361159.
            </p>
            <p>LIFE FORT INTERNATIONAL MINISTRY.<br>
               FIRST BANK.<br>
               2022269209.
            </p>
        </div>

        <!-- <div class="col-md-6" id="map"></div> -->
      </div>
    </div>
  </div>

<?php include 'includes/footer.php';?>