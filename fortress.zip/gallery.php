<title>The Fortress International Church - Gallery</title>
<?php include 'includes/head.php';?>
<?php include 'includes/nav-gallery.php';?>
<?php include 'includes/heading-gallery.php';?>  

  
  <div class="site-section">
    <div class="container-fluid pad-left-right-15">
      <div class="row no-gutters">
        <div class="col-md-4">
          <a href="img/Random/20190505112825__MG_8313.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Random/20190505112825__MG_8313.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>
        <div class="col-md-4">
          <a href="img/Pst-Jumoke/IMG-20190305-WA0035.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Pst-Jumoke/IMG-20190305-WA0035.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>
        <div class="col-md-4">
          <a href="img/Pst-Kelvin/20190602114606__MG_9191.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Pst-Kelvin/20190602114606__MG_9191.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>

        <div class="col-md-4">
          <a href="img/Pst-Desmond/20190522195748__MG_8754.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Pst-Desmond/20190522195748__MG_8754.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>
        <div class="col-md-4">
          <a href="img/Random/20190512113903__MG_8431.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Random/20190512113903__MG_8431.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>
        <div class="col-md-4">
          <a href="img/Random/20190505112627__MG_8308.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Random/20190505112627__MG_8308.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>

         <div class="col-md-4">
          <a href="img/Random/20190505112932__MG_8316.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Random/20190505112932__MG_8316.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>
        <div class="col-md-4">
          <a href="img/Pst-Jumoke/20180722110645_IMG_6809.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Pst-Jumoke/20180722110645_IMG_6809.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>
        <div class="col-md-4">
          <a href="img/Random/20190609114434__MG_9583.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Random/20190609114434__MG_9583.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>

        <div class="col-md-4">
          <a href="img/Random/20190512103509__MG_8381.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Random/20190609121838__MG_9606.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>
        <div class="col-md-4">
          <a href="img/Pst-Kelvin/20190512114722__MG_8446.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Pst-Kelvin/20190512114722__MG_8446.jpg" alt="The Fortress Int'l Church" class="img-fluid" style="transform: rotate(-90deg);">
          </a>
        </div>
        <div class="col-md-4">
          <a href="img/Pst-Jumoke/20190127120446__MG_5803.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Pst-Jumoke/20190127120446__MG_5803.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>

        <div class="col-md-4">
          <a href="img/Random/20190519103013__MG_8533.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Random/20190519103013__MG_8533.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>
        <div class="col-md-4">
          <a href="img/Pst-Desmond/IMG-20190305-WA0034.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Pst-Desmond/IMG-20190305-WA0034.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>
        <div class="col-md-4">
          <a href="img/Random/20190519113649__MG_8577.jpg" class="image-popup img-hover">
            <span class="icon icon-search"></span>
            <img src="img/Random/20190519113649__MG_8577.jpg" alt="The Fortress Int'l Church" class="img-fluid">
          </a>
        </div>
      </div>
    </div>
  </div>
  
<?php include 'includes/footer.php';?>  
